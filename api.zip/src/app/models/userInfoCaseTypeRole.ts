export type UserInfoCaseTypeRole = 'Rebates' | 'Trading' | 'Trading Lux' | 'All';

export const UserInfoCaseTypeRole = {
    Rebates: 'Rebates' as UserInfoCaseTypeRole,
    Trading: 'Trading' as UserInfoCaseTypeRole,
    TradingLux: 'Trading Lux' as UserInfoCaseTypeRole,
    All: 'All' as UserInfoCaseTypeRole
};

