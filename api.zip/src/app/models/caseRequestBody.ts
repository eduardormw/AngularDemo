import { CasePriority } from './casePriority';
import { CaseType } from './caseType';
import { CaseStatus } from './caseStatus';

export interface CaseRequestBody { 
    subject: string;
    caseNumber?: string;
    type?: CaseType;
    status?: CaseStatus;
    priority?: CasePriority;
    description?: string;
    socialSecurityNumber?: string;
    endClientName?: string;
}
export namespace CaseRequestBody {
}


