export type CaseStatus = 'Ongoing' | 'New' | 'Closed' | 'Completed';

export const CaseStatus = {
    Ongoing: 'Ongoing' as CaseStatus,
    New: 'New' as CaseStatus,
    Closed: 'Closed' as CaseStatus,
    Completed: 'Completed' as CaseStatus
};

