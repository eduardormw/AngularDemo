export interface CaseCommentRequestBody { 
    body?: string;
}

