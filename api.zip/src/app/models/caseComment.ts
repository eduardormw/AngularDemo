export interface CaseComment { 
    id?: string;
    body?: string;
    contactName?: string;
    lastModifiedDate?: string;
}

