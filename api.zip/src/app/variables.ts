import { InjectionToken } from '@angular/core';
import { ChartOptions, ChartType } from 'chart.js';
import { Case } from '@models/case';
import { CaseType } from '@models/caseType';
import { UserInfoCaseTypeRole } from '@models/UserInfoCaseTypeRole';

export const BASE_PATH = new InjectionToken < string > ('basePath');
export const COLLECTION_FORMATS = {
  'csv': ',',
  'tsv': '   ',
  'ssv': ' ',
  'pipes': '|'
}

// An array of allowed file types for file upload
export const ALLOWED_FILE_TYPES = ['.png', '.jpg', '.pdf', '.xls', '.xlsx', '.csv', '.doc', '.docx'];

// Background colors for charts
export const CHART_BACKGROUND_COLOR = ["#46a0db", "#1c3359", "#90dcd8", "#4aa49e", "#b4d77d", "#dfce88", "#d7b77d"];

// Chart types for available chart types
export const CHART_TYPES: ChartType[] = ['doughnut', 'pie', 'bar', 'line'];

// Boolean value for showing chart legend
export const CHART_LEGEND = true;

// Options for configuring charts
export const CHART_OPTIONS: ChartOptions = {
  responsive: true,
  maintainAspectRatio: true,
  animation: { duration: 0 },
  plugins: { legend: { position: 'right' } }
};

// Case object properties
type CaseLabels = {
  [key in keyof Case]: {
    key: key,
    label: string, // Label
    default ? : boolean, // Default column
    chart ? : boolean, // Chart data
    details ? : boolean, // Details tab field
    editable ? : boolean // If can be edited
  };
} [keyof Case];

export const CASE_LABELS: CaseLabels[] = [
  { key: 'id', label: 'ID' },
  { key: 'caseNumber', label: 'Case Number', default: true, details: true },
  { key: 'caseNumberLegacy', label: 'Legacy Case Number' },
  { key: 'subject', label: 'Subject', default: true, details: true },
  { key: 'type', label: 'Case Record Type', default: true, chart: true, details: true },
  { key: 'status', label: 'Status', default: true, details: true },
  { key: 'lastModifiedDate', label: 'Last Modified Date', default: true, details: true },
  { key: 'priority', label: 'Priority', default: true, chart: true, details: true },
  { key: 'description', label: 'Description', details: true },
  { key: 'contactName', label: 'Contact Name', chart: true, details: true, editable: true },
  { key: 'socialSecurityNumber', label: 'Social Security Number', details: true },
  { key: 'endClientName', label: 'End Client Name', details: true },
  { key: 'escalated', label: 'Escalated' }
];

// Case types by client type
type UserTypeCaseType = {
  [key in UserInfoCaseTypeRole]: Array < CaseType > ;
};


export const CASE_CLIENT_TYPES: UserTypeCaseType = {
  Rebates: [
    CaseType.FundOrderQuery,
    CaseType.FundRequest,
    CaseType.GeneralQuery,
    CaseType.RebatesRateRequest,
  ],
  Trading: [
    CaseType.CorporateActionQuery,
    CaseType.FundDataQuery,
    CaseType.FundOrderQuery,
    CaseType.FundRequest,
    CaseType.GeneralQuery,
    CaseType.PaymentQuery,
    CaseType.SwitchOrder,
    CaseType.TransferQuery,
    CaseType.WaiverRequest
  ],
  'Trading Lux': [
    CaseType.CorporateActionQuery,
    CaseType.FundDataQuery,
    CaseType.FundOrderQuery,
    CaseType.FundRequest,
    CaseType.GeneralQuery,
    CaseType.NewDistributorAccount,
    CaseType.OrderCancellation,
    CaseType.PaymentQuery,
    CaseType.SwitchOrder
  ],
  All: [
    ...Object.values(CaseType),
  ],
};

// Case types by mfex type
export const CASE_MFEX_TYPES = [
  CaseType.CorporateActionNotification,
  CaseType.LateRedemptionPayment,
  CaseType.NAVCorrection,
  CaseType.OutstandingSubscriptionPayment,
  CaseType.RejectedOrder
];
