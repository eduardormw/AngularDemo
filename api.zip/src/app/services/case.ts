import { Injectable } from '@angular/core';
// import { HttpClient } from '@angular/common/http';
import { Observable, of } from 'rxjs';

import { Case } from '@models/case';
import { mockData } from './mock-data';

@Injectable({
  providedIn: 'root',
})
export class CaseService {
  // protected baseUrl = 'http://localhost/cases';
  private baseUrl: Case[] = mockData;

  // constructor(private http: HttpClient) { }
  constructor() {}

  getCases(): Observable < Case[] > {
    // return this.http.get<Case[]>(this.baseUrl);
    return of(this.baseUrl);
  }

  getCase(id: string): Observable < Case | undefined > {
    const result = this.baseUrl.find((c) => c.id === id);
    return result ? of (result) : of (undefined);
  }

  getCasesByDateRange(fromDate: string, toDate: string, attribute: string): Observable < { data: number[], labels: string[] } > {
    const casesInRange = this.baseUrl.filter((c) => {
      const caseDate = new Date(c.lastModifiedDate);
      return caseDate >= new Date(fromDate) && caseDate <= new Date(toDate);
    });

    const data = casesInRange.reduce((totals, c) => {
      const attrValue = c[attribute as keyof Case];
      if (typeof attrValue === 'string' && !totals.labels.includes(attrValue)) {
        totals.labels.push(attrValue);
        totals.data.push(1);
      } else if (typeof attrValue === 'string') {
        const index = totals.labels.indexOf(attrValue);
        totals.data[index] += 1;
      }
      return totals;
    }, { data: [] as number[], labels: [] as string[] });
    return of(data);
  }

}
