import { Component, OnInit, Output, EventEmitter } from '@angular/core';
// import { Router } from '@angular/router';
import { Case } from '@models/case';
import { CaseType } from '@models/caseType';
import { CaseStatus } from '@models/caseStatus';
import { UserInfoCaseTypeRole } from '@models/UserInfoCaseTypeRole';

import { CaseService } from '@services/case';

import { CASE_LABELS, CASE_CLIENT_TYPES, CASE_MFEX_TYPES } from '@variables';

@Component({
  selector: 'app-cases-table',
  templateUrl: './cases-table.component.html',
  styleUrls: ['./cases-table.component.scss'],
})

export class CasesTableComponent implements OnInit {
  // Outputs the case clicked
  @Output() caseClicked = new EventEmitter < string[] > ();
  // Outputs the case type to create
  @Output() caseTypeClicked = new EventEmitter < string > ();

  private cases: Case[] = [];
  public filteredCases: Case[] = [];
  public searchTerm: string = '';
  public sortField: keyof Case = 'caseNumber';
  public sortDirection: 'asc' | 'desc' = 'asc';
  private userType = UserInfoCaseTypeRole.Rebates;
  public readonly caseTypes: CaseType[] = CASE_CLIENT_TYPES[this.userType];
  public readonly caseMfexTypes = CASE_MFEX_TYPES;
  public readonly caseStatuses: CaseStatus[] = Object.values(CaseStatus);
  public filter: { type: "all" | CaseType, mfexType: "all" | CaseType, status: "all" | CaseStatus, my: boolean } = { type: "all", mfexType: "all", status: CaseStatus.Ongoing, my: false };
  public readonly tableHeaders = CASE_LABELS;
  public defaultFilter: typeof this.filter = { ...this.filter };

  constructor(private caseService: CaseService /*, private router: Router*/ ) {}

  ngOnInit(): void {
    this.tableHeaders.sort((a, b) => a.label.localeCompare(b.label));
    
    // Get the list of all cases
    this.caseService.getCases().subscribe((cases) => {
      this.cases = cases;
      this.filteredCases = cases;
      this.onSearch();
    });
  }

  // Filters cases based on search term or status type
  public onSearch = (): void => {
    this.filteredCases = this.cases.filter((c) => {
      return (
        (c && c.caseNumber && c.caseNumber.toString().includes(this.searchTerm)) ||
        (c && c.subject && c.subject.toLowerCase().includes(this.searchTerm.toLowerCase())) ||
        (c && c.contactName && c.contactName.toLowerCase().includes(this.searchTerm.toLowerCase()))
      ) && (
        this.filter.status === 'all' || c.status === this.filter.status
      ) && (
        this.filter.type === 'all' || c.type === this.filter.type
      ) && (
        this.filter.mfexType === 'all' || c.type === this.filter.mfexType
      );
    });
  }

  // Filters cases according to the dropdowns
  public onFilterChange(value: any, property: string): void {
    switch (property) {
      case 'type':
        this.filter.type = value as CaseType;
        break;
      case 'mfexType':
        this.filter.mfexType = value as CaseType;
        break;
      case 'status':
        this.filter.status = value as CaseStatus;
        break;
      case 'my':
        this.filter.my = value;
        break;
      default:
        break;
    }
    this.onSearch();
  }

  // Shows my cases


  // Sorts cases based on the sort field and direction
  private sortCases = (
    cases: Case[],
    sortField: keyof Case,
    sortDirection: 'asc' | 'desc'
  ): Case[] => {
    return cases.sort((a, b) => {
      const aValue = a[sortField];
      const bValue = b[sortField];
      if (aValue < bValue) {
        return sortDirection === 'asc' ? -1 : 1;
      } else if (aValue > bValue) {
        return sortDirection === 'asc' ? 1 : -1;
      } else {
        return 0;
      }
    });
  }

  // Sets the sort field, direction and updates the cases
  public onSort = (field: keyof Case): void => {
    this.sortField = field;
    this.sortDirection = this.sortDirection === 'asc' ? 'desc' : 'asc';
    this.filteredCases = this.sortCases(
      this.filteredCases,
      this.sortField,
      this.sortDirection
    );
  }

  // Updates the table headers
  public updateTableHeaders = (value: string): void => {
    const headerToUpdate = this.tableHeaders.find(
      (header) => header.key === value
    );
    if (headerToUpdate) {
      headerToUpdate.default = !headerToUpdate.default;
    }
  }

  // Emits the clicked case id
  public showCaseDetails = (clicked: Case): void => {
    const emitData: any = {
      id: clicked.id,
      caseNumber: clicked.caseNumber
    };

    this.caseClicked.emit(emitData);
  }

  // Opens the tab for new case
  public createCase = (typeClicked: string): void => {
    this.caseTypeClicked.emit(typeClicked);
  }

  // Compares and resets the filters
  public resetFilter(): void {
    console.log(this.filter);
    console.log(this.defaultFilter);

    this.filter = this.filter = { ...this.defaultFilter };
    this.onSearch();
  }

  public areFiltersEqual(): boolean {
    return JSON.stringify(this.filter) !== JSON.stringify(this.defaultFilter);
  }
}
