import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { Case } from '@models/case';
import { CaseType } from '@models/caseType';
import { CaseService } from '@services/case';
import { ByteFormat } from '@pipes/byteformat';
import { ALLOWED_FILE_TYPES, CASE_LABELS } from '@variables';

@Component({
  selector: 'app-case-details',
  templateUrl: './case-details.component.html',
  styleUrls: ['./case-details.component.scss']
})

export class CaseDetailsComponent implements OnInit {
  // Case to show
  @Input() id?: string | null; 

  public case?: Case; 
  public readonly caseLabels = CASE_LABELS; 
  public isTransferQuery: boolean = false;

  constructor(private caseService: CaseService) {}

  ngOnInit(): void {
    // Calls the getCase function of the case service if a case number is provided
    if (this.id) {
      this.caseService.getCase(this.id).subscribe((caseData) => {
        this.case = caseData;
        this.isTransferQuery = this.case?.type === CaseType.TransferQuery;
      });
    }
  }

  // Prints the current case, hiding the tabs and input elements (CSS)
  public printPage = (): void => {
    window.print();
  }

  // Validates file types for file upload
  public onFileSelected = (event: any) => {
    const files = event.target.files;
    const invalidFiles = [];

    // Loops through the selected files and checks if they have an allowed file type
    for (let i = 0; i < files.length; i++) {
      const file = files[i];
      const fileType = file.type;
      const fileName = file.name;
      const fileExtension = fileName.substr(fileName.lastIndexOf('.')).toLowerCase();
      if (!ALLOWED_FILE_TYPES.includes(fileExtension)) {
        invalidFiles.push(fileName);
      }
    }

    // If there are invalid files, an alert is shown with the invalid file types and the allowed file types
    if (invalidFiles.length > 0) {
      const message = 'Invalid file type(s): ' + invalidFiles.join(', ') + '.\n\nAllowed file types are: ' + ALLOWED_FILE_TYPES.join(', ');
      alert(message);
      event.target.value = null; // clear the selected files
      return;
    }
  }
}
