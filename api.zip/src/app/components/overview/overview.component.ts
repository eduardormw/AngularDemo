import { Component, OnInit } from '@angular/core';
import { DatePipe } from '@angular/common';
import { CaseService } from '@services/case';
import { CASE_LABELS, CHART_BACKGROUND_COLOR, CHART_TYPES, CHART_OPTIONS, CHART_LEGEND } from '@variables';

import { ChartTypeRegistry } from 'chart.js';

@Component({
  selector: 'app-overview',
  templateUrl: './overview.component.html',
  styleUrls: ['./overview.component.scss'],
})
export class OverviewComponent implements OnInit {
  public totalCases: number = 0;
  public fromDate: string;
  public toDate: string;
  public caseLabels = CASE_LABELS;
  public chartTypes = CHART_TYPES;
  public chartOptions = CHART_OPTIONS;
  public chartLegend = CHART_LEGEND;

  // creates the chart object and sets default values, add more to generate more charts
  public chart: {
    [key: string]: {
      attr: {
        field: string;
        label: string;
        type: keyof ChartTypeRegistry;
      };
      results: {
        data: number[];
        labels: string[];
        label: string;
        backgroundColor: string[];
      } [];
    };
  } = { 
    left: {
      attr: { field: "status", label: "Status", type: "doughnut" },
      results: [{ data: [], labels: [], label: "Cases found", backgroundColor: CHART_BACKGROUND_COLOR }],
    },
    right: {
      attr: { field: "type", label: "Case Record Type", type: "doughnut" },
      results: [{ data: [], labels: [], label: "Cases found", backgroundColor: CHART_BACKGROUND_COLOR }],
    }
  };

  constructor(private caseService: CaseService, private datePipe: DatePipe) {
    const oneMonthAgo = new Date();
    oneMonthAgo.setMonth(oneMonthAgo.getMonth() - 1);
    // convert the start date of the date range to a string format
    this.fromDate = this.datePipe.transform(oneMonthAgo, 'yyyy-MM-dd') || '';
    // convert the end date of the date range to a string format
    this.toDate = this.datePipe.transform(new Date(), 'yyyy-MM-dd') || '';
  }

  ngOnInit() {
    // load all charts on initialization
    this.loadAllCharts();
  }
  
  // method to update the date range and chart data based on the selected date range
  public updateDateRange = (side: string) => { 
    this.caseService.getCasesByDateRange(this.fromDate, this.toDate, this.chart[side].attr.field).subscribe((result: { data: number[], labels: string[] }) => {
      this.chart[side].results[0].data = result.data; 
      this.chart[side].results[0].labels = result.labels; 
      // calculate the total number of cases for the time range
      this.totalCases = result.data.reduce((acc, val) => acc + val, 0);
    });
  }

  // updates the chart according to field or type
  public updateChart = (side: string, option: { key: string, label: string } | keyof ChartTypeRegistry): void => {
    if (typeof option === 'object' && 'key' in option) {
      this.chart[side].attr.field = option.key;
      this.chart[side].attr.label =option.label
    } else {
      this.chart[side].attr.type = option;
    }
    this.updateDateRange(side);
  }

  // loads all charts
  public loadAllCharts = () => {
    for (const key of Object.keys(this.chart)) {
      this.updateDateRange(key);
    }
  }

  // gets all chart object keys 
  public getChartKeys = (): string[] => {
    return Object.keys(this.chart);
  }

}
