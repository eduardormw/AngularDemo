import { CaseAttachmentMimeType } from './caseAttachmentMimeType';

export interface CaseAttachment { 
    readonly id?: string;
    fileName?: string;
    lastModified?: string;
    contactName?: string;
    size?: number;
    mimeType?: CaseAttachmentMimeType;
}
export namespace CaseAttachment {
}


