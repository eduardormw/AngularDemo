export type CaseStatus = 'New' | 'Closed' | 'Completed' | 'Ongoing';

export const CaseStatus = {
    New: 'New' as CaseStatus,
    Closed: 'Closed' as CaseStatus,
    Completed: 'Completed' as CaseStatus,
    Ongoing: 'Ongoing' as CaseStatus
};

