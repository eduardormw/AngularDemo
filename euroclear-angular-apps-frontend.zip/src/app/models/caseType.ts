export type CaseType = 'Fund Order Query' | 'Fund Request' | 'New Distributor Account' | 'Order Cancellation' | 'Rebates Rate Request' | 'Switch Order' | 'Transfer Query' | 'Waiver Request' | 'Corporate Action Query' | 'Fund Data Query' | 'General Query' | 'Payment Query';

export const CaseType = {
    FundOrderQuery: 'Fund Order Query' as CaseType,
    FundRequest: 'Fund Request' as CaseType,
    NewDistributorAccount: 'New Distributor Account' as CaseType,
    OrderCancellation: 'Order Cancellation' as CaseType,
    RebatesRateRequest: 'Rebates Rate Request' as CaseType,
    SwitchOrder: 'Switch Order' as CaseType,
    TransferQuery: 'Transfer Query' as CaseType,
    WaiverRequest: 'Waiver Request' as CaseType,
    CorporateActionQuery: 'Corporate Action Query' as CaseType,
    FundDataQuery: 'Fund Data Query' as CaseType,
    GeneralQuery: 'General Query' as CaseType,
    PaymentQuery: 'Payment Query' as CaseType,
};
