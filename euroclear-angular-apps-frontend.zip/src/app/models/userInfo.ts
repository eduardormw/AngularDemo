import { UserInfoCaseTypeRole } from './userInfoCaseTypeRole';

export interface UserInfo { 
    caseTypeRole?: UserInfoCaseTypeRole;
}
export namespace UserInfo {
}


