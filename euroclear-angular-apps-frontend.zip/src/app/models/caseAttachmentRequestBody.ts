import { CaseAttachmentMimeType } from './caseAttachmentMimeType';


export interface CaseAttachmentRequestBody { 
    contents?: string;
    fileName?: string;
    mimeType?: CaseAttachmentMimeType;
}
export namespace CaseAttachmentRequestBody {
}


