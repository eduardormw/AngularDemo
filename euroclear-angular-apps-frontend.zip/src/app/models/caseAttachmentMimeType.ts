export type CaseAttachmentMimeType = 'image/png' | 'image/jpeg' | 'application/pdf' | 'application/msword' | 'application/vnd.openxmlformats-officedocument.wordprocessingml.document' | 'application/vnd.ms-excel' | 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' | 'text/csv';

export const CaseAttachmentMimeType = {
    ImagePng: 'image/png' as CaseAttachmentMimeType,
    ImageJpeg: 'image/jpeg' as CaseAttachmentMimeType,
    ApplicationPdf: 'application/pdf' as CaseAttachmentMimeType,
    ApplicationMsword: 'application/msword' as CaseAttachmentMimeType,
    ApplicationVndOpenxmlformatsOfficedocumentWordprocessingmlDocument: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document' as CaseAttachmentMimeType,
    ApplicationVndMsExcel: 'application/vnd.ms-excel' as CaseAttachmentMimeType,
    ApplicationVndOpenxmlformatsOfficedocumentSpreadsheetmlSheet: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' as CaseAttachmentMimeType,
    TextCsv: 'text/csv' as CaseAttachmentMimeType
};

