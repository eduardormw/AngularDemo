import { CaseAttachment } from './caseAttachment';

export interface CaseAttachmentList { 
    /**
     * a list of attachments
     */
    attachments?: Array<CaseAttachment>;
}

