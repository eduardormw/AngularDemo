import { Component } from '@angular/core';

@Component({
  selector: 'mfex-list',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss'],
})
export class AppComponent {
  // An array to store the opened cases
  public openCases: any[] = [];
  // An array to store the opened forms
  public openForms: any[] = [];
  // A string to store the active tab
  public currentTab = '';

  private eTypes: Map < string, any[] > = new Map([
    ['case', this.openCases],
    ['form', this.openForms],
  ]);


  // Method to set the current tab to the selected tab, or an empty string if no tab is selected
  public selectTab(tab ? : string): void {
    this.currentTab = tab ? tab : '';
  }

  // Show the details of a selected case or a new form
  public createTab(type: string, selected: any): void {
    const eType = this.eTypes.get(type);
    if (type === 'case') {
      const existingCase = this.openCases.find((openCase) => openCase.id === selected.id);
      if (!existingCase) {
        this.openCases.push(selected);
      }
      this.selectTab(selected.id);
    } else if (type === 'form') {
      const existingForm = this.openForms.find((openForm) => openForm === selected);
      if (!existingForm) {
        this.openForms.push(selected);
      }
      this.selectTab(selected);
    }
  }

  // Close the details of a case or a new form
  public closeTab(type: string, closedItem: any): void {
    const eType = this.eTypes.get(type);
    if (eType) {
      const index = eType.findIndex((item) => item === closedItem);
      if (index >= 0) {
        eType.splice(index, 1);
      }
    }

    this.selectTab();
  }
}
