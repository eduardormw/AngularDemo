import { Case } from '@models/case';
import { CasePriority } from '@models/casePriority';
import { CaseType } from '@models/caseType';
import { CaseStatus } from '@models/caseStatus';
import { CaseAttachmentMimeType } from '@models/caseAttachmentMimeType';

export const mockData: Case[] = [{
    id: '1',
    caseNumber: '00001',
    caseNumberLegacy: '000074110',
    subject: 'Lorem ipsum',
    type: CaseType.TransferQuery,
    status: CaseStatus.Ongoing,
    lastModifiedDate: '2023-03-01 16:53',
    priority: CasePriority.Low,
    description: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla magna odio, faucibus a nunc vel, scelerisque convallis libero. Nulla facilisi. Fusce ullamcorper odio eu nisl convallis dignissim. Etiam vulputate, lacus ac luctus dignissim, ipsum est bibendum lacus, sed tincidunt elit arcu in tellus.',
    contactName: 'John Doe',
    socialSecurityNumber: '123456789',
    endClientName: 'John Doe',
    escalated: false,
    comments: [{
        id: "101",
        body: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin vel vestibulum ipsum. Fusce sodales massa at ligula volutpat, id euismod quam sollicitudin. Sed dignissim ex a ante sodales, eget iaculis arcu facilisis. Donec eget elit non elit dignissim rhoncus. Nulla venenatis blandit elit in elementum. Nulla ullamcorper, elit eu fermentum pulvinar, odio augue sollicitudin eros, nec laoreet sapien eros eget augue. Praesent ac augue quis tellus bibendum eleifend a quis est.",
        contactName: "John Smith",
        lastModifiedDate: "2022-01-01 12:00:00"
      },
      {
        id: "102",
        body: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse lacinia eros et ipsum blandit, nec suscipit lorem venenatis. ",
        contactName: "Jane Doe",
        lastModifiedDate: "2022-01-02 10:30:00"
      },
      {
        id: "103",
        body: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut volutpat, sem ac varius ultrices, massa ipsum posuere justo, ut blandit nunc risus nec arcu. Donec ac justo sit amet mi posuere luctus. Sed sagittis velit vel euismod ullamcorper. Nam sit amet nulla vel metus congue volutpat eget in nisl. Proin vel ipsum id enim congue rutrum a ac nunc. Fusce tristique erat non luctus elementum. Duis nec libero in turpis sollicitudin feugiat. Nam interdum ex vitae fermentum venenatis. Vivamus venenatis blandit elit eu faucibus. Donec auctor erat vitae mauris laoreet, vel congue est placerat. Praesent vitae dui pharetra, malesuada dui ac, maximus odio. Ut suscipit turpis sit amet velit fermentum, eu tristique orci varius. Curabitur nec ante libero.",
        contactName: "Bob Johnson",
        lastModifiedDate: "2022-01-03 15:45:00"
      },
      {
        id: "104",
        body: "This is the fourth comment on case 1",
        contactName: "Samantha Lee",
        lastModifiedDate: "2022-01-04 16:20:00"
      }
    ],
    attachments: [{
        id: "1",
        fileName: "attachment1.png",
        lastModified: "2023-04-25 14:30:00",
        contactName: "Jane Smith",
        size: 1024,
        mimeType: CaseAttachmentMimeType.ImagePng
      },
      {
        id: "2",
        fileName: "attachment2.pdf",
        lastModified: "2023-04-25 14:45:00",
        contactName: "Jane Smith",
        size: 20448,
        mimeType: CaseAttachmentMimeType.ApplicationPdf
      }
    ]
  },
  {
    id: '2',
    caseNumber: '00002',
    caseNumberLegacy: '0000157',
    subject: 'Pellentesque vel dapibus nulla',
    type: CaseType.NewDistributorAccount,
    status: CaseStatus.Completed,
    lastModifiedDate: '2023-03-01 16:53',
    priority: CasePriority.High,
    description: 'Pellentesque vel dapibus nulla. Nullam sit amet magna efficitur, sollicitudin est vitae, tincidunt nibh. Proin commodo justo sit amet ornare iaculis. Integer efficitur pharetra nunc a lacinia. Nullam commodo nunc in felis iaculis auctor.',
    contactName: 'Jane Smith',
    socialSecurityNumber: '987654321',
    endClientName: 'John Doe',
    escalated: true,
    comments: [],
    attachments: []
  },
  {
    id: '3',
    caseNumber: '00003',
    caseNumberLegacy: '00002123',
    subject: 'Lorem ipsum dolor sit amet',
    type: CaseType.SwitchOrder,
    status: CaseStatus.New,
    lastModifiedDate: '2023-03-02 11:22',
    priority: CasePriority.Low,
    description: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec imperdiet augue non sem malesuada, vitae convallis massa aliquet. Sed euismod sodales dui id bibendum.',
    contactName: 'John Doe',
    socialSecurityNumber: '123456789',
    endClientName: 'John Doe',
    escalated: false,
    comments: [],
    attachments: []
  }
];
