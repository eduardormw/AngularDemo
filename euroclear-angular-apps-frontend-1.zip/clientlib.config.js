// MANAGED BY ACOLAD, DO NOT CHANGE THIS FILE
module.exports = {
    // default working directory (can be changed per 'cwd' in every asset option)
    context: __dirname,

    // path to the clientlib root folder (output)
    clientLibRoot: "../euroclear-angular-apps-design/src/main/content/jcr_root/etc/clientlibs/euroclear-angular-apps",

    // define all clientlib options here as array... (multiple clientlibs)
    libs: [
      {
        name: "euroclear.angular.clientlib",
        serializationFormat: "xml",
        assets: {
            js: [
                "dist/**/*.js"
            ],
            css: [
                "dist/**/*.css"
            ]
        }
      },
    ],
  }