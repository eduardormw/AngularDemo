import { CasePriority } from './casePriority';
import { CaseType } from './caseType';
import { CaseStatus } from './caseStatus';
import { CaseComment } from './caseComment';
import { CaseAttachment } from './caseAttachment';

export interface Case {
  id: string;
  caseNumber: string;
  caseNumberLegacy: string;
  subject: string;
  type: CaseType;
  status: CaseStatus;
  lastModifiedDate: string;
  priority: CasePriority;
  description: string;
  contactName: string;
  socialSecurityNumber: string;
  endClientName: string;
  escalated: boolean;
  comments: CaseComment[];
  attachments: CaseAttachment[];
}