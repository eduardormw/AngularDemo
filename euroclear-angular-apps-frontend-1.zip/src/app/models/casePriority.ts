export type CasePriority = 'Low' | 'Medium' | 'High';

export const CasePriority = {
    Low: 'Low' as CasePriority,
    Medium: 'Medium' as CasePriority,
    High: 'High' as CasePriority
};

