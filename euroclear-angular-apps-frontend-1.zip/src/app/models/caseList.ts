import { Case } from './case';


export interface CaseList { 
    count?: number;
    /**
     * A list of cases
     */
    cases?: Array<Case>;
}

