import { CaseComment } from './caseComment';

export interface CaseCommentList { 
    /**
     * a list of comments
     */
    comments?: Array<CaseComment>;
}

