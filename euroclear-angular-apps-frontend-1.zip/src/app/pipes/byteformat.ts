import { Pipe, PipeTransform } from '@angular/core';

@Pipe({ name: 'bytesToMb' })

export class ByteFormat implements PipeTransform {
  transform(value: number | undefined): string {
    if (!value) return '';
    const mb = value / 1024;
    return mb.toFixed(2) + ' MB';
  }
}
