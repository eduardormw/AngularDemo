import { Injector, NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';
import { createCustomElement } from '@angular/elements';
import { DatePipe } from '@angular/common';
import { ByteFormat } from '@pipes/byteformat';
import { NgChartsModule } from 'ng2-charts';

import { AppComponent } from './app.component';
import { CasesTableComponent } from '@components/cases-table/cases-table.component';
import { CaseDetailsComponent } from '@components/case-details/case-details.component';
import { OverviewComponent } from '@components/overview/overview.component';


@NgModule({
  declarations: [AppComponent, CasesTableComponent, CaseDetailsComponent, OverviewComponent, ByteFormat],
  imports: [BrowserModule, FormsModule, NgChartsModule],
  providers: [DatePipe],
  bootstrap: [AppComponent],
})
export class AppModule {
  constructor(private injector: Injector) {};

  ngDoBootstrap() {
    const customElement = createCustomElement(CasesTableComponent, { injector: this.injector });

    customElements.define('mfex-list', customElement);
  }

}
